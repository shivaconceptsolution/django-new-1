from django.shortcuts import render
def home(request):
    return render(request,"jobapp/home.html")
def about(request):
    return render(request,"jobapp/about.html")
def services(request):
    return render(request,"jobapp/services.html")
def gallery(request):
    return render(request,"jobapp/gallery.html")
def contact(request):
    return render(request,"jobapp/contact.html")